#!/usr/bin/env python3
"""
Cross-reference a BookingLayer export against the LaWayra LEADS workbook
and output a media-buyer attribution table.

Usage:
    python3 attribute.py <BookingLayer.xlsx> <LEADS.xlsx>

Output: markdown table to stdout, plus tally and unmatched-list.
"""
import sys
import re
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from difflib import SequenceMatcher

import openpyxl

from sheet_config import (
    SHEET_CONFIG, HEADER_START,
    GG_LEADS_SHEET, GG_LEADS_NAME_COL, GG_LEADS_EMAIL_COL, GG_LEADS_DATE_COL,
    GG_LEADS_IMPLICIT_SOURCE,
    SHEET13_NAME, SHEET13_FIRST, SHEET13_LAST, SHEET13_EMAIL, SHEET13_CREATED,
    attribute_buyer,
)


# ---------- helpers ----------

def strip_accents(s: str) -> str:
    return ''.join(c for c in unicodedata.normalize('NFD', s or '')
                   if unicodedata.category(c) != 'Mn')


def norm_name(s) -> str:
    if not s:
        return ""
    s = strip_accents(str(s)).lower()
    return re.sub(r'\s+', ' ', s.strip())


def parse_dt(v):
    """Parse a value into a naive datetime. Handles datetimes, Unix timestamps (s/ms), ISO strings."""
    if v is None or v == '':
        return None
    if isinstance(v, datetime):
        return v
    if isinstance(v, (int, float)):
        try:
            if 1e9 < v < 2e10:        # seconds
                return datetime.fromtimestamp(v, tz=timezone.utc).replace(tzinfo=None)
            if 1e12 < v < 2e13:       # milliseconds
                return datetime.fromtimestamp(v / 1000, tz=timezone.utc).replace(tzinfo=None)
        except Exception:
            pass
        return None
    s = str(v).strip()
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


def normalize_source(raw) -> str:
    """Map various source labels to standard codes: GG / TT / FB / other."""
    if not raw:
        return ""
    s = str(raw).strip().upper()
    if "GG" in s or "GOOGLE" in s:
        return "GG Ads"
    if "TT" in s or "TIKTOK" in s:
        return "TT Ads"
    if "FB" in s or "FACEBOOK" in s or "META" in s:
        return "FB Ads"
    return str(raw).strip()


# ---------- data loading ----------

def load_bl_bookings(path: str):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["Worksheet"]
    bookings = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[5]:
            continue
        bookings.append({
            "name": str(row[5]).strip(),
            "name_norm": norm_name(row[5]),
            "booking_num": row[2],
            "created": row[0],
            "source": row[1],
            "status": row[3],
            "total": row[6],
        })
    return bookings


def load_leads_index(path: str):
    """Build name_norm -> [(sheet, email, created_dt, source)] index."""
    wb = openpyxl.load_workbook(path, data_only=True)
    name_idx = defaultdict(list)

    for sheet_name, (fi, li, ei, ti, si) in SHEET_CONFIG.items():
        if sheet_name not in wb.sheetnames:
            continue
        ws = wb[sheet_name]
        start = HEADER_START.get(sheet_name, 2)
        for row in ws.iter_rows(min_row=start, values_only=True):
            cols_needed = [c for c in [fi, li, ei, ti, si] if c is not None]
            if not cols_needed or max(cols_needed) >= len(row):
                continue
            full = f"{row[fi] or ''} {row[li] or ''}".strip()
            nn = norm_name(full)
            if not nn:
                continue
            src = row[si] if si is not None else None
            name_idx[nn].append((sheet_name, row[ei], parse_dt(row[ti]), src))

    # GG Leads (special)
    if GG_LEADS_SHEET in wb.sheetnames:
        ws = wb[GG_LEADS_SHEET]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or len(row) <= max(GG_LEADS_NAME_COL, GG_LEADS_EMAIL_COL, GG_LEADS_DATE_COL):
                continue
            name = row[GG_LEADS_NAME_COL]
            if not name:
                continue
            name_idx[norm_name(name)].append((
                GG_LEADS_SHEET,
                row[GG_LEADS_EMAIL_COL],
                parse_dt(row[GG_LEADS_DATE_COL]),
                GG_LEADS_IMPLICIT_SOURCE,
            ))

    # Sheet13 (GHL contacts)
    if SHEET13_NAME in wb.sheetnames:
        ws = wb[SHEET13_NAME]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or len(row) <= max(SHEET13_FIRST, SHEET13_LAST, SHEET13_EMAIL, SHEET13_CREATED):
                continue
            full = f"{row[SHEET13_FIRST] or ''} {row[SHEET13_LAST] or ''}".strip()
            if not full:
                continue
            name_idx[norm_name(full)].append((
                SHEET13_NAME, row[SHEET13_EMAIL], parse_dt(row[SHEET13_CREATED]), None,
            ))

    return name_idx


# ---------- matching ----------

def find_match(bl_name_norm: str, name_idx: dict):
    found = name_idx.get(bl_name_norm, [])
    if found:
        return found
    # Try reversed order (last first)
    parts = bl_name_norm.split()
    if len(parts) >= 2:
        rev = " ".join(reversed(parts))
        found = name_idx.get(rev, [])
        if found:
            return found
    return []


def fuzzy_candidates(bl_name_norm: str, all_leads, threshold: float = 0.85):
    """Return a list of (score, full, email, sheet, why) for fuzzy matches."""
    parts = bl_name_norm.split()
    bl_first, bl_last = (parts[0], parts[-1]) if len(parts) >= 2 else (None, None)
    candidates = []
    for nn, (full, email, sheet) in all_leads:
        if nn == bl_name_norm:
            continue
        f_parts = nn.split()
        f_first, f_last = (f_parts[0], f_parts[-1]) if len(f_parts) >= 2 else (None, None)
        # Last name + first initial
        if bl_last and f_last and bl_last == f_last and bl_first and f_first and bl_first[0] == f_first[0]:
            candidates.append((0.95, full, email, sheet, "last+initial"))
            continue
        r = SequenceMatcher(None, bl_name_norm, nn).ratio()
        if r >= threshold:
            candidates.append((r, full, email, sheet, f"ratio={r:.2f}"))
    return sorted(candidates, key=lambda x: -x[0])[:5]


# ---------- main ----------

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 attribute.py <BookingLayer.xlsx> <LEADS.xlsx>", file=sys.stderr)
        sys.exit(1)

    bl_path, leads_path = sys.argv[1], sys.argv[2]
    bookings = load_bl_bookings(bl_path)
    name_idx = load_leads_index(leads_path)

    matched = []
    unmatched = []
    for b in bookings:
        hits = find_match(b["name_norm"], name_idx)
        if not hits:
            unmatched.append(b)
            continue
        with_date = [h for h in hits if h[2] is not None]
        chosen = min(with_date, key=lambda x: x[2]) if with_date else hits[0]
        sheet, email, created, src = chosen
        # If chosen record has no source, look across all hits for one
        if not src:
            for h in hits:
                if h[3]:
                    src = h[3]
                    break
        # Aggregate all distinct sources across hits
        all_sources = sorted({str(h[3]) for h in hits if h[3]})
        matched.append({
            "booking": b,
            "email": email,
            "created": created,
            "source_raw": src,
            "source": normalize_source(src),
            "all_sources": all_sources,
            "sheet": sheet,
            "buyer": attribute_buyer(created, src),
        })

    # ---- Output ----
    print(f"\n## Lead Attribution Report\n")
    print(f"**Matched:** {len(matched)} of {len(bookings)} BL bookings\n")

    print("| Name | BL # | BL Source | Email | Lead Created | Days→Booking | Traffic Source | Media Buyer |")
    print("|---|---|---|---|---|---|---|---|")
    for m in matched:
        b = m["booking"]
        cdate = m["created"].strftime("%Y-%m-%d") if m["created"] else "(no date)"
        days = (b["created"] - m["created"]).days if m["created"] else "—"
        print(f"| {b['name']} | {b['booking_num']} | {b['source']} | "
              f"{m['email'] or 'n/a'} | {cdate} | {days} | "
              f"{m['source'] or 'n/a'} | {m['buyer']} |")

    # Tally
    tally = defaultdict(int)
    for m in matched:
        tally[m["buyer"]] += 1
    print(f"\n**Tally by media buyer:**")
    for buyer, n in sorted(tally.items(), key=lambda x: -x[1]):
        print(f"- {buyer}: {n}")

    # Long nurture wins (>180 days)
    long_nurture = [m for m in matched
                    if m["created"] and (m["booking"]["created"] - m["created"]).days > 180]
    if long_nurture:
        print(f"\n**Long-nurture wins (>180 days lead → booking):**")
        for m in long_nurture:
            d = (m["booking"]["created"] - m["created"]).days
            print(f"- {m['booking']['name']}: {d} days ({m['source']})")

    # Unmatched
    if unmatched:
        print(f"\n**Unmatched ({len(unmatched)}):**")
        for b in unmatched:
            print(f"- {b['name']} | BL#{b['booking_num']} | {b['source']}")


if __name__ == "__main__":
    main()
