"""
Column layout for each tab of the LaWayra LEADS workbook.
Update if Marcus reorganizes the workbook.

Tuple format: (first_name_col, last_name_col, email_col, time_created_col, source_col)
- Use None for source_col if the sheet has no source column.
- For sheets where the data starts at row 1 (no header), set start_row in HEADER_START.
"""

SHEET_CONFIG = {
    "Leads":                       (0, 1, 7, 20, 21),
    "Copy of Leads 1":             (0, 1, 7, 19, 20),
    "Sheet9":                      (0, 1, 5, 18, 19),
    "Extra Leads":                 (0, 1, 5, 18, None),
    "Sales Android Leads":         (0, 1, 5, 18, 19),
    "USCanada":                    (0, 1, 5, 17, 18),
    "Copy of Leads":               (0, 1, 7, 20, 21),
    "YogaRetreats-LawayraWellness":(0, 1, 7, 20, 21),
}

# Sheets where data starts at row 1 (no header row)
HEADER_START = {
    "Sheet9": 1,
}

# Special-case sheets
# GG Leads: full name in col 1, email col 2, phone col 3, submission date col 0
GG_LEADS_SHEET = "GG Leads"
GG_LEADS_NAME_COL = 1
GG_LEADS_EMAIL_COL = 2
GG_LEADS_DATE_COL = 0
GG_LEADS_IMPLICIT_SOURCE = "GG Ads"

# Sheet13: GHL contact export — first/last in cols 1/2, email col 6, created col 7
SHEET13_NAME = "Sheet13"
SHEET13_FIRST = 1
SHEET13_LAST = 2
SHEET13_EMAIL = 6
SHEET13_CREATED = 7

# Media buyer cutoffs (lead-create date attribution)
# (start_inclusive_or_None, end_exclusive_or_None, google_buyer, other_buyer)
# Order matters - first match wins.
from datetime import datetime
CUTOFFS = [
    # (start, end, GG, TT/FB/other)
    (None,                       datetime(2024, 9, 17), "Marcus", "Marcus"),
    (datetime(2024, 9, 17),      datetime(2025, 5, 7),  "Hafsa",  "Marcus"),
    (datetime(2025, 5, 7),       datetime(2025, 10, 13),"Ida",    "Marcus"),
    (datetime(2025, 10, 13),     datetime(2025, 10, 27),"Marcus", "Marcus"),
    (datetime(2025, 10, 27),     None,                  "Andrew", "Andrew"),
]


def attribute_buyer(lead_created: datetime, source: str) -> str:
    """Return the media buyer for a lead based on create-date and channel."""
    if not lead_created:
        return "(unknown - no date)"
    src = (source or "").upper()
    is_google = "GG" in src or "GOOGLE" in src
    for start, end, gg_buyer, other_buyer in CUTOFFS:
        if start and lead_created < start:
            continue
        if end and lead_created >= end:
            continue
        return gg_buyer if is_google else other_buyer
    return "(unknown)"
