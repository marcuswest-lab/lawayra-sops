---
name: lead-attribution
description: Cross-reference a BookingLayer bookings export (.xlsx) against the LaWayra LEADS workbook (.xlsx) and output a media-buyer attribution table with name, BL #, BL source, email, lead-create date, traffic source (GG/TT/FB), and attributed media buyer. Use when the user provides a BookingLayer export plus the updated LEADS sheet and asks to match bookings to leads, attribute commissions, or determine which media buyer generated each booking. Trigger phrases include "lead attribution", "cross-check bookings", "match BL to leads", "media buyer attribution", "who gets credit for these bookings".
user_invocable: true
---

# Lead Attribution: BookingLayer ↔ LEADS Cross-Reference

Match BookingLayer bookings to LaWayra leads and attribute each one to the media buyer who was running ads on the lead-create date.

---

## When to Use

- User provides a BookingLayer export (e.g. `Bookinglayer-Bookings-YYYY-MM-DD.xlsx`) AND a LEADS workbook (e.g. `LEADS.xlsx` or `LEADS (N).xlsx`)
- User asks to figure out who closed the leads, who deserves commission, or which booking came from which ads channel
- User asks for a "lead attribution table" or "match BL to leads"

---

## Required Inputs

1. **BookingLayer xlsx** — sheet `Worksheet`, columns: Created on, Source, Booking #, Status, Check-in on, **Booker** (name), Total, Due, Pax. **No email column.**
2. **LEADS xlsx** — multi-sheet workbook with these known tabs and their column layouts (verify on each run; user occasionally reorders):

| Sheet | First | Last | Email | Time Created | Source | Notes |
|---|---|---|---|---|---|---|
| `Leads` | 0 | 1 | 7 | 20 | 21 | Master sheet, 4500+ rows |
| `Copy of Leads 1` | 0 | 1 | 7 | 19 | 20 | No WhatsApp col |
| `Sheet9` | 0 | 1 | 5 | 18 | 19 | No header row — data starts row 1 |
| `Extra Leads` | 0 | 1 | 5 | 18 | — | No source col |
| `GG Leads` | (full name in col 1) | — | 2 | 0 | implicit "GG Ads" | Google Ads form fills |
| `Sales Android Leads` | 0 | 1 | 5 | 18 | 19 | |
| `USCanada` | 0 | 1 | 5 | 17 | 18 | |
| `Sheet13` | 1 | 2 | 6 | 7 | — | GHL contacts |
| `Copy of Leads` | 0 | 1 | 7 | 20 | 21 | |
| `YogaRetreats-LawayraWellness` | 0 | 1 | 7 | 20 | 21 | |

**Time Created** is sometimes a `datetime`, sometimes a Unix timestamp as `float` (seconds since epoch, e.g. `1726575687.0` = 2024-09-17). Both must be handled.

---

## Media Buyer Cutoffs (lead-create date attribution)

**ALWAYS use lead-create date, NOT booking date.** See full citations in memory: `project_media_buyer_cutoffs.md`.

| Period | Google Ads | TikTok / Other |
|---|---|---|
| pre-9/17/2024 | **Marcus** | **Marcus** |
| 9/17/2024 → 5/7/2025 | **Hafsa** | Marcus (TT was paused most of this window) |
| 5/7/2025 → 10/13/2025 | **Ida** | Marcus (TT relaunched 6/17/25) |
| 10/13/2025 → 10/27/2025 | **Marcus** | Marcus |
| 10/27/2025 → present | **Andrew** | Andrew |

TT (TikTok) leads are NEVER attributed to Hafsa or Ida — they were Google-only. FB Ads same — TT/FB were Marcus/in-house.

---

## Workflow

### Step 1: Locate the files
- Default search: `~/Desktop/LW/Claude Code LW/`, then `~/Downloads/`
- Use Glob with patterns `*Bookinglayer*.xlsx` and `LEADS*.xlsx` if user didn't give explicit paths
- Confirm filenames with the user if multiple matches

### Step 2: Run the matching script
Use the Python script at `scripts/attribute.py` (in this skill folder). It:
1. Loads the BL `Worksheet` tab → list of bookings with `Booker` name
2. Loads every known sheet of the LEADS workbook → builds a name index
3. Normalizes names (lowercase, strip accents, collapse whitespace)
4. Matches BL.Booker against name index (exact + reversed first/last)
5. Pulls earliest dated record per match (in case of duplicates)
6. Parses Time Created as datetime OR Unix timestamp
7. Looks up media buyer based on lead-create date + source channel
8. Outputs the table

```bash
cd ~/.claude/skills/lead-attribution
python3 scripts/attribute.py "<path-to-BL.xlsx>" "<path-to-LEADS.xlsx>"
```

### Step 3: Present the table
Standard output format (markdown table):

| Name | BL # | BL Source | Email | Lead Created | Days→Booking | Traffic Source | Media Buyer |
|---|---|---|---|---|---|---|---|

Plus:
- **Tally**: count by media buyer (Andrew = X, Hafsa = Y, Marcus = Z, etc.)
- **Match summary**: "N of M BL bookings matched in LEADS"
- List of unmatched BL bookings (so user can manually attribute or flag)

### Step 4: Fuzzy pass (optional)
For unmatched names, run a secondary fuzzy search (last name + first initial, swapped order, sequence ratio ≥0.85). Present candidates to user for confirmation — never auto-promote a fuzzy match.

---

## Output Conventions

- **Traffic Source labels** (preserve as found in LEADS):
  - `GG Ads` / `GG` → Google Ads
  - `TT Ads` / `TT` → TikTok Ads
  - `FB Ads` → Facebook/Meta Ads
  - `(blank)` or `n/a` → flag for user
- **Media Buyer**: one of `Marcus`, `Hafsa`, `Ida`, `Andrew`. Never guess if lead-create date is missing — output `(unknown)` and flag.
- **Highlight long-tail wins**: any booking where Days→Booking > 180, call out separately as "long nurture".

---

## Common Edge Cases

1. **Same-day lead → booking** (Days = 0): often a sales-rep direct conversion, not paid-ads attribution. Flag for review.
2. **Lead with no Time Created**: drop date attribution, default to "current era" media buyer (Andrew) only if BL booking date is recent (< 60 days). Otherwise output `(unknown)`.
3. **Multiple "Derek Davis" type collisions**: name index returns multiple hits — use earliest date and flag in output.
4. **Accented names** (e.g. "Kim Siljamäki"): script strips accents for matching but preserves original in output.
5. **Reversed first/last**: e.g. BL "andrew tattersall" vs LEADS "Tattersall, Andrew" — script tries reversed match.
6. **The 5/7 vs 5/12 ambiguity for Ida's start**: only matters if a lead falls in that 5-day window. If so, flag for user judgment.

---

## Files in this Skill

- `SKILL.md` — this file
- `scripts/attribute.py` — the matching + attribution script
- `scripts/sheet_config.py` — LEADS sheet column layout (update if user reorganizes the workbook)

---

## Related Memory

- `project_media_buyer_cutoffs.md` — full source citations for the cutoff dates (WhatsApp chat lines)
- `project_sales_tracking_logic.md` — broader two-dimension attribution context (marketing source ≠ sales rep)
